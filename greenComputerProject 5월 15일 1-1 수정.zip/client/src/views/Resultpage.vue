<template>
  <div class="result">
    <div class="result-page">
      <!-- 이미지와 텍스트를 표시할 컨테이너 -->
      <div class="content-container">
        <!-- 왼쪽에 이미지 표시 -->
        <div class="image-container">
          <img :src="imageUrl1" alt="Result Image 1" v-if="imageUrl1" style="width: 100%; height: auto;">
          <img :src="imageUrl2" alt="Result Image 2" v-if="imageUrl2" style="width: 100%; height: auto;">
          <img :src="imageUrl3" alt="Result Image 3" v-if="imageUrl3" style="width: 100%; height: auto;">
        </div>
        
        <!-- 오른쪽에 텍스트 표시 -->
        <div class="text-container">
          <div class="title-box" v-for="(item, index) in titles" :key="index">
            <p class="title-font"><strong>제목:</strong> {{ item }} </p>
          </div>
          <div class="keyword-box" v-for="(item, index) in keywords" :key="index">
            <p class="keyword-font"><strong>키워드:</strong> {{ item }} </p>
          </div>
          <div class="description-box" v-for="(item, index) in descriptions" :key="index">
            <p class="description-font"><strong>해설:</strong> {{ item }} </p>
            <p class="description-content"><strong>설명 내용:</strong> {{ descriptionContents[index] }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      imageUrl1: '', // 이미지 URL 1
      imageUrl2: '', // 이미지 URL 2
      imageUrl3: '', // 이미지 URL 3
      titles: [], // 제목 데이터 배열
      keywords: [], // 키워드 데이터 배열
      descriptions: [], // 해설 데이터 배열
      descriptionContents: [] // 설명 내용 데이터 배열
    };
  },
  mounted() {
    // Imageupload.vue에서 전달한 이미지 URL을 받아옵니다.
    this.imageUrl1 = this.$route.query.imageUrl1;
    this.imageUrl2 = this.$route.query.imageUrl2;
    this.imageUrl3 = this.$route.query.imageUrl3;

    // 가상의 텍스트 데이터를 설정합니다. (실제 데이터를 받아와야 합니다.)
    this.titles = ["나무", "집", "사람"];
    this.keywords = ["자연", "건물", "인물"];
    this.descriptions = ["나무를 표현한 그림입니다.", "집을 나타낸 그림입니다.", "사람을 나타낸 그림입니다."];
    this.descriptionContents = ["나무는 자연을 상징합니다.", "집은 안정과 편안함을 의미합니다.", "사람은 인간의 존재를 나타냅니다."];
  }
};
</script>

<style scoped>
.result {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.result-page {
}

.content-container {
  display: flex;
  justify-content: space-between;
}

.image-container {
  flex: 1;
}

.image-container img {
  max-width: 100%;
  height: auto;
}

.text-container {
  flex: 1;
}

.title-box {
  margin-bottom: 20px;
}

.keyword-box {
  margin-bottom: 20px;
}

.description-box {
  margin-bottom: 20px;
}

.title-font {
  font-size: 20px;
}

.keyword-font {
  font-size: 16px;
}

.description-font {
  font-size: 16px;
}

.description-content {
  font-size: 14px;
}
</style>
